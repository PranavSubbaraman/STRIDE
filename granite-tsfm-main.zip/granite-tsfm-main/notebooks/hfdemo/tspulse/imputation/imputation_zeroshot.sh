python imputation_zeroshot.py  --datasets ETTh1 ETTh2 ETTm1 ETTm2 weather electricity \
                               --mask_type block hybrid \
                               --mask_ratio 0.125 0.25 0.375 0.5